Cufon.replace('#menu a, .pagination li, h2', { fontFamily: 'Questrial', hover:true });

